package com.adwo.androidofferwall;

import com.zkmm.appoffer.OfferListener;
import com.zkmm.appoffer.ZkmmAppOffer;

import android.app.Activity;
import android.os.Bundle;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.MultiAutoCompleteTextView;
import android.widget.Toast;

/**
 * @author Adwo
 * 安沃Android积分墙嵌入工程实例
 */
public class AdwoAppOfferActivity extends Activity implements OnClickListener ,OfferListener{
	private Button click;
	private Button spend;
	private Button show;
	MultiAutoCompleteTextView spendAmount;
	private ZkmmAppOffer appOffer;
	@Override
	public void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.main);
		
		appOffer = ZkmmAppOffer.getInstance(this,"730a9bab4d194630882a2e3045980ffa");
		appOffer.setOfferListener(this);
		String[] strs = new String[]{"android_test_keywords_one"
				,"android_test_keywords_two","android_test_keywords_three"};
		appOffer.setKeywords(strs);
		
		click = (Button) findViewById(R.id.click_btn);
		spend = (Button) findViewById(R.id.spend_btn);
		show = (Button) findViewById(R.id.show_btn);
		click.setOnClickListener(this);
		spend.setOnClickListener(this);
		show.setOnClickListener(this);
		
		spendAmount = (MultiAutoCompleteTextView) findViewById(R.id.spendAmount);
	}
	
	@Override
	public void onClick(View v) {
		if (v == click) {
			  appOffer.showOffer(this);
			  
		}
		if (v == spend) {
			String num = spendAmount.getText().toString();
			if(num!=null && !"".equals(num)){
				int p = Integer.decode(num);
				int ap = appOffer.consumeVirtualCurrency(this, p);
				if (ap>0) {
					Toast.makeText(this, "成功花费"+ap+"个积分",Toast.LENGTH_LONG).show();
				}else
					Toast.makeText(this, "积分不足或者消费积分数除兑换比例的值为零",Toast.LENGTH_LONG).show();
			}else{
				Toast.makeText(this, "请输入积分",Toast.LENGTH_LONG).show();
			}
			
		}
		if (v == show) {
			Toast.makeText(this, "本地积分总数" + appOffer.getTotalOfferVirtualCurrency(this),Toast.LENGTH_LONG).show();
		}
		
	}

	/* (non-Javadoc)
	 * @see com.zkmm.appoffer.OfferListener#onReceiveAd()
	 * 积分墙初始化成功回调接口
	 */
	@Override
	public void onReceiveAd() {
		Toast.makeText(AdwoAppOfferActivity.this, "积分墙初始化成功!", Toast.LENGTH_SHORT).show();
	}

	/* (non-Javadoc)
	 * @see com.zkmm.appoffer.OfferListener#onFailedToReceiveAd()
	 * 积分墙初始化失败回调接口
	 */
	@Override
	public void onFailedToReceiveAd() {
		Toast.makeText(AdwoAppOfferActivity.this, "积分墙初始化不成功,有可能是由于请求频繁，请稍候再次请求。", Toast.LENGTH_SHORT).show();
	}
	
	
	@Override
	protected void onDestroy() {
//		销毁夹在进度条对话框，因为在跳出当前activity是如果不再这里调用销毁进度条，会导致对话框失去附属activity。
		if(appOffer!=null){
			appOffer.dismissProgressDialog();
		}
		super.onDestroy();
	}

}